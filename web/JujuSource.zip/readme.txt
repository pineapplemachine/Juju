Juju is Sudoku written in Java! This program and its source code are
released as public domain. (But that doesn't mean you should claim credit
that isn't yours, or sell it when it could otherwise be had for free, 
because that would be a shitty thing of you to do.)
Juju was written by Sophie Kirschner. Visit the author's website at
http://pineapplemachine.com